package com.Library_Management_System.Library_Management_System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
