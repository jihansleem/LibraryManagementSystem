package com.Library_Management_System.Repository;

import java.util.Optional;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Library_Management_System.Entities.Book;

@Repository
@ComponentScan(basePackages = "com.Library_Management_System.Controller")
@ComponentScan(basePackages = "com.Library_Management_System.Library_Management_System")
public interface BookRepository extends JpaRepository<Book, Long> {

	
Optional<Book> findById(Long id);
Book getBookById(Long id);
void delete(Book book);

}