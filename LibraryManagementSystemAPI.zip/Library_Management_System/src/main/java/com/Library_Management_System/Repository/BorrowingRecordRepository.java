package com.Library_Management_System.Repository;

import java.util.List;
import java.util.Optional;

import com.Library_Management_System.Entities.BorrowingRecord;
import com.Library_Management_System.Entities.Book;
import com.Library_Management_System.Entities.Patron;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BorrowingRecordRepository extends JpaRepository<BorrowingRecord, Long> {

    Optional<BorrowingRecord> findById(Long id);

    BorrowingRecord findByBookAndPatronAndReturnDateIsNull(Book book, Patron patron);

    List<BorrowingRecord> findByBookAndReturnDateIsNull(Book book);
}
