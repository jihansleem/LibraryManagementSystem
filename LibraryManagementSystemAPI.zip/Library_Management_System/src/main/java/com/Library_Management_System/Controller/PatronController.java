package com.Library_Management_System.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Library_Management_System.Entities.Patron;
import com.Library_Management_System.Repository.PatronRepository;

import jakarta.validation.Valid;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;


@RestController
@RequestMapping("/api/patrons")
@ComponentScan(basePackages = "com.Library_Management_System.Repository")
@ComponentScan(basePackages = "com.Library_Management_System.Library_Management_System")
public class PatronController {

    @Autowired
    private PatronRepository patronRepository;
    
    public PatronController(PatronRepository patronRepository) {
    	this.patronRepository = patronRepository;
    }

    @Cacheable("patrons")
    @GetMapping("/")
    public List<Patron> getAllPatrons() {
        return patronRepository.findAll();
    }
    
    @Cacheable("patron")
    @GetMapping("/{id}")
    public ResponseEntity<Patron> getPatronById(@PathVariable Long id) {
        Patron patron = patronRepository.findById(id).orElse(null);
        if (patron == null) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(patron);
        }
    }

    @PostMapping
    @CacheEvict(value = "patrons", allEntries = true) // Clears the "patrons" cache after creating a new patron
    @Transactional
    public ResponseEntity<Patron> createPatron(@Valid @RequestBody Patron patron) {
        Patron savedPatron = patronRepository.save(patron);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedPatron);
    }

    @PutMapping("/{id}")
    @CacheEvict(value = "patrons", allEntries = true) // Clears the "patrons" cache after updating a patron
    @Transactional
    public Patron updatePatron(@PathVariable Long id, @Valid @RequestBody Patron patron) {
        Patron existingPatron = patronRepository.findById(id).orElseThrow(() -> new RuntimeException("Patron not found"));
        existingPatron.setName(patron.getName());
        existingPatron.setContactInformation(patron.getContactInformation());
        return patronRepository.save(existingPatron);
    }

    @DeleteMapping("/{id}")
    @CacheEvict(value = "patrons", allEntries = true) // Clears the "patrons" cache after deleting a patron
    @Transactional
    public ResponseEntity<Void> deletePatron(@PathVariable Long id) {
        Patron existingPatron = patronRepository.findById(id).orElse(null);
        if (existingPatron == null) {
            return ResponseEntity.notFound().build();
        } else {
            patronRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
    }
}
