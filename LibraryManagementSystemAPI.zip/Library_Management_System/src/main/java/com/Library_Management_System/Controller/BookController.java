package com.Library_Management_System.Controller;


import java.util.List;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Library_Management_System.Entities.Book;
import com.Library_Management_System.Repository.BookRepository;

import jakarta.validation.Valid;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;

import com.Library_Management_System.Repository.BookRepository;


@ComponentScan(basePackages = "com.Library_Management_System.Repository")
@ComponentScan(basePackages = "com.Library_Management_System.Library_Management_System")


@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookRepository bookRepository;
    
    public BookController(BookRepository bookRepository) {
    	this.bookRepository= bookRepository;
    	}
    
    @Cacheable("books")
    @GetMapping("/")
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    /*@GetMapping("/{id}")
    public Book getBookById(@PathVariable Long id) {
        return bookRepository.findById(id).orElseThrow(() -> new RuntimeException("Book not found"));
    }*/

    @Cacheable("books")
    @GetMapping("/{id}")
    public ResponseEntity<Book> getCustomerById(@PathVariable Long id) {
    	Book book = bookRepository.findById(id).orElse(null);
    if (book == null) {
    return ResponseEntity.notFound().build();
    } else {
    return ResponseEntity.ok(book);
    }
    }

    
    /*@PostMapping
    public Book addBook(@RequestBody Book book) {
        return bookRepository.save(book);
    }*/

    
    @PostMapping
    @CacheEvict(value = "books", allEntries = true) // Clears the "books" cache after creating a new book
    @Transactional
    public ResponseEntity<Book> createBook(@Valid @RequestBody Book book) {
    Book savedBook = bookRepository.save(book);
    return ResponseEntity.status(HttpStatus.CREATED).body(savedBook);
    }
    
    
    @PutMapping("/{id}")
    @CacheEvict(value = "books", allEntries = true) // Clears the "books" cache after updating a book
    @Transactional
    public Book updateBook(@PathVariable Long id, @Valid @RequestBody Book book) {
        Book existingBook = bookRepository.findById(id).orElseThrow(() -> new RuntimeException("Book not found"));
        existingBook.setTitle(book.getTitle());
        existingBook.setAuthor(book.getAuthor());
        existingBook.setIsbn(book.getIsbn());
        existingBook.setPublicationYear(book.getPublicationYear());
        return bookRepository.save(existingBook);
    }
    
    

    @DeleteMapping("/{id}")
    @CacheEvict(value = "books", allEntries = true) // Clears the "books" cache after deleting a book
    @Transactional
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
    	 Book existingBook = bookRepository.findById(id).orElse(null);
    	    if (existingBook == null) {
    	    return ResponseEntity.notFound().build();
    	    } else {
    	    	bookRepository.deleteById(id);
    	    return ResponseEntity.noContent().build();
    	    }
    	    }
    

}
