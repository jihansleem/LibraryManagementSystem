package com.Library_Management_System.Controller;

import com.Library_Management_System.Entities.Book;
import com.Library_Management_System.Entities.BorrowingRecord;
import com.Library_Management_System.Entities.Patron;
import com.Library_Management_System.Repository.BookRepository;
import com.Library_Management_System.Repository.BorrowingRecordRepository;
import com.Library_Management_System.Repository.PatronRepository;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import com.Library_Management_System.Entities.Book;
import com.Library_Management_System.Entities.Patron;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/borrowing-records")
public class BorrowingRecordController {

    @Autowired
    private BorrowingRecordRepository borrowingRecordRepository;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private PatronRepository patronRepository;

    @Cacheable("borrowingRecords")

    @GetMapping("/")
    public List<BorrowingRecord> getAllBorrowingRecords() {
        return borrowingRecordRepository.findAll();
    }

    @Cacheable("borrowingRecords")
    @GetMapping("/{id}")
    public ResponseEntity<BorrowingRecord> getBorrowingRecordById(@Valid @PathVariable Long id) {
        BorrowingRecord borrowingRecord = borrowingRecordRepository.findById(id).orElse(null);
        return borrowingRecord != null
                ? ResponseEntity.ok(borrowingRecord)
                : ResponseEntity.notFound().build();
    }

    @PostMapping("/borrow/{bookId}/patron/{patronId}")
    @CacheEvict(value = "borrowingRecords", allEntries = true) // Clears the "borrowingRecords" cache after creating a new borrowing record
    @Transactional
    public ResponseEntity<Object> borrowBook(
            @PathVariable Long bookId,
            @PathVariable Long patronId
            ) {
        Book book = bookRepository.findById(bookId).orElse(null);
        Patron patron = patronRepository.findById(patronId).orElse(null);

        if (book == null || patron == null) {
            return ResponseEntity.notFound().build();
        }

        if (bookIsAvailableForBorrowing(book)) {
            BorrowingRecord borrowingRecord = new BorrowingRecord();
            borrowingRecord.setBook(book);
            borrowingRecord.setPatron(patron);
            borrowingRecord.setBorrowingDate(LocalDate.now());

            BorrowingRecord savedRecord = borrowingRecordRepository.save(borrowingRecord);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedRecord);
        } else {
            return ResponseEntity.badRequest().body("The book is not available for borrowing.");
        }
    }

    @PutMapping("/return/{bookId}/patron/{patronId}")
    @CacheEvict(value = "borrowingRecords", allEntries = true) // Clears the "borrowingRecords" cache after updating a borrowing record
    @Transactional
    public ResponseEntity<Object> returnBook(
            @PathVariable Long bookId,
            @PathVariable Long patronId
    ) {
        Book book = bookRepository.findById(bookId).orElse(null);
        Patron patron = patronRepository.findById(patronId).orElse(null);

        if (book == null || patron == null) {
            return ResponseEntity.notFound().build();
        }

        BorrowingRecord borrowingRecord = borrowingRecordRepository
                .findByBookAndPatronAndReturnDateIsNull(book, patron);

        if (borrowingRecord == null) {
            return ResponseEntity.badRequest().body("The specified book is not borrowed by the patron.");
        } else {
            borrowingRecord.setReturnDate(LocalDate.now());
            BorrowingRecord savedRecord = borrowingRecordRepository.save(borrowingRecord);
            return ResponseEntity.ok(savedRecord);
        }
    }

    private boolean bookIsAvailableForBorrowing(Book book) {
        return borrowingRecordRepository.findByBookAndReturnDateIsNull(book).isEmpty();
    }
    
    
    @DeleteMapping("/{id}")
    @CacheEvict(value = "borrowingRecords", allEntries = true) // Clears the "borrowingRecords" cache after deleting a borrowing record
    @Transactional
    public ResponseEntity<Object> deleteBorrowingRecord(@PathVariable Long id) {
        BorrowingRecord borrowingRecord = borrowingRecordRepository.findById(id).orElse(null);

        if (borrowingRecord == null) {
            return ResponseEntity.notFound().build();
        }

        borrowingRecordRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
