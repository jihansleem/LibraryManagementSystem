package com.Library_Management_System.Entities;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.time.Year;
import java.time.Year;

import org.springframework.context.annotation.ComponentScan;

@Entity
@ComponentScan(basePackages = "com.Library_Management_System.Repository")
@ComponentScan(basePackages = "com.Library_Management_System.Controller")

public class Book {
   
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Title cannot be blank")
    private String title;
    
    @NotBlank(message = "Author cannot be blank")
    private String author;
    
    @NotBlank(message = "ISBN cannot be blank")
    @Pattern(regexp = "\\d{3}-\\d{10}", message = "Invalid ISBN format")
    private String isbn;


    @NotNull(message = "Publication year cannot be null")
    private Year publicationYear;
    

    // Constructors, Getters, Setters
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public Year getPublicationYear() {
		return publicationYear;
	}
	public void setPublicationYear(Year publicationYear) {
		this.publicationYear = publicationYear;
	}
	@Override
	public String toString() {
		return "Book [id=" + id + ", title=" + title + ", author=" + author + ", isbn=" + isbn + ", publicationYear="
				+ publicationYear + ", getId()=" + getId() + ", getTitle()=" + getTitle() + ", getAuthor()="
				+ getAuthor() + ", getIsbn()=" + getIsbn() + ", getPublicationYear()=" + getPublicationYear()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	public Book(Long id, String title, String author, String isbn, Year publicationYear) {
		super();
		this.id = id;
		this.title = title;
		this.author = author;
		this.isbn = isbn;
		this.publicationYear = publicationYear;
	}

    
}