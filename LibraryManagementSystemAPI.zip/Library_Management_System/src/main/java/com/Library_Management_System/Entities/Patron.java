package com.Library_Management_System.Entities;

//import javax.persistence.*;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
public class Patron {
    
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @NotBlank(message = "Name cannot be blank")
    private String name;
    

    @NotBlank(message = "Contact information cannot be blank")
    private String contactInformation;
    
    // Constructors, Getters, Setters
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContactInformation() {
		return contactInformation;
	}
	public void setContactInformation(String contactInformation) {
		this.contactInformation = contactInformation;
	}
	@Override
	public String toString() {
		return "Patron [id=" + id + ", name=" + name + ", contactInformation=" + contactInformation + ", getId()="
				+ getId() + ", getName()=" + getName() + ", getContactInformation()=" + getContactInformation()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	public Patron(Long id, String name, String contactInformation) {
		super();
		this.id = id;
		this.name = name;
		this.contactInformation = contactInformation;
	}

   
    
}