package com.Library_Management_System.Aspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Aspect
@Component
public class LoggingAspect {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Before("execution(* com.Library_Management_System.Controller.BookController.*(..))")
    public void logBookControllerMethods(JoinPoint joinPoint) {
        logger.info("Method called: " + joinPoint.getSignature().getName());
    }

    @AfterThrowing(pointcut = "execution(* com.Library_Management_System.Controller.*.*(..))", throwing = "exception")
    public void logExceptions(JoinPoint joinPoint, Exception exception) {
        logger.error("Exception in method " + joinPoint.getSignature().getName() + ": " + exception.getMessage());
    }
}
